/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.awt.Graphics;
import javax.swing.JFrame;


public class Bresnham extends JFrame{

  
    public void paint(Graphics g)
    {
       
        int x1,y1,x2,y2,swap,i,s1,s2,e;
        
          x1=200;
        y1=100;
        x2=500;
        y2=500;
        
        int dx,dy;
        dx=Math.abs(x2-x1);
        dy=Math.abs(y2-y1);
        
        if(dy>dx)
        {
            int temp=dx;
            dx=dy;
            dy=temp;
            
            swap=1;
        }
        else
            swap=0;
        
       s1=sign(x2,x1);
       s2=sign(y2,y1);
       
       i=0;
       
       e=2*dy-dx;
       
       
       int x=x1;
       int y=y1;
       
       
       g.fillOval(x, y,2, 2);
       
        while(i<=dx)
        {
          
            if(e>=0)
            {
              x=x+s1;
              y=y+s2;
              e=e+2*dy-2*dx;
                
                
            }
            else
            {
                if(swap==1)
                    y=y+s2;
                else
                    x=x+s1;
                
             e=e+2*dy;   
              
     
            }
            g.fillOval(x, y, 2, 2);
            System.out.println("the x and y value"+ x  +"   "+ y);
            i++;
            
            
        }
        
        
        
        
        
        
    }
    
    
  public  int sign(int a,int b)
    {
        if(a>b)
            return 1;
        if(a<b)
            return -1;
       
            return 0;
        
    }
    
    public static void main(String[] args) 
    {
        Bresnham b= new Bresnham();
        b.setSize(1500, 1500);
        b.setVisible(true);
        
    }
    
}
