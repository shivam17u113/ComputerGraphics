/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.awt.Color;
import java.awt.Graphics;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author shivam patil
 */
public class TRans  extends JFrame{
    
 static   int size =3;
  static  int [][] vert= new int[size][3];
  static  double [][] s=new double [size][3];
 static   double [][]  t= new double [size][3];
  static  double [][]  r=new double[size][3];
    static  int [][] c= new int[size][3]; 
    
    
    
    
    
    public void paint(Graphics g)
    {
        
     try {
         vert[0][0]=300;
         vert[0][1]=300;
         vert[0][2]=1;
         vert[1][0]=150;
         vert[1][1]=500;
         vert[1][2]=1;
         vert[2][0]=450;
         vert[2][1]=500;
         vert[2][2]=1;
         
         
         t[0][0]=1;
         t[0][1]=0;
         t[0][2]=0;
         t[1][0]=0;
         t[1][1]=1;
         t[1][2]=0;
         t[2][0]=600;
         t[2][1]=0;
         t[2][2]=1;
         
         s[0][0]=2;
         s[0][1]=0;
         s[0][2]=0;
         s[1][0]=0;
         s[1][1]=1;
         s[1][2]=0;
         s[2][0]=0;
         s[2][1]=0;
         s[2][2]=1;
         
         
         int angle = 5;
         double rad= Math.PI*angle/180;
         
         r[0][0]=Math.cos(rad);
         r[0][1]=Math.sin(rad);
         r[0][2]=0;
         r[1][0]=-Math.sin(rad);
         r[1][1]=Math.cos(rad);
         r[1][2]=0;
         r[2][0]=0;
         r[2][1]=0;
         r[2][2]=1;
         
         
         dr(g);
         mat_mul(vert,t);
         dr_c(g);
         
         Thread.sleep(1000);
         
         
         g.clearRect(0, 0, 2000, 2000);
         g.setColor(Color.white);
         g.fillRect(0, 0, 2000, 2000);
         
         
         
         dr(g);
         mat_mul(vert,s);
         dr_c(g);
         
         
            Thread.sleep(1000);
         g.clearRect(0, 0, 2000, 2000);
         g.setColor(Color.white);
         g.fillRect(0, 0, 2000, 2000);
         
         
         dr(g);
         mat_mul(vert,r);
         dr_c(g);
         
         
         
         
     } catch (InterruptedException ex) {
         Logger.getLogger(TRans.class.getName()).log(Level.SEVERE, null, ex);
     }
       
        
        
    }
  
    public void dr(Graphics g)
    {
        g.setColor(Color.blue);
        for(int i=0;i<size;i++)
      g.drawLine(vert[i%size][0], vert[i%size][1], vert[(i+1)%size][0], vert[(i+1)%size][1]);
        
    }
    
    
     public void dr_c(Graphics g)
    {
        g.setColor(Color.red);
        for(int i=0;i<size;i++)
      g.drawLine(c[i%size][0], c[i%size][1], c[(i+1)%size][0], c[(i+1)%size][1]);
        
    }
     
     public void mat_mul(int [][] a, double[] [] b)
     {
         
         for(int i=0;i<size;i++)
         {
           for(int j=0;j<3;j++)
           {
               c[i][j]=0;
             for(int k=0;k<3;k++)
             {
               c[i][j]=(int) (a[i][k]*b[k][j] +c[i][j]);  
                 
             }
               
           }
             
             
         }
           
     }
     
    
    public static void main(String[] args) {
        TRans t= new TRans();
        t.setSize(2000, 2000);
        t.setVisible(true);
        
    }
    
}
