#include <graphics.h> 
#include<iostream> 
using namespace std; 

void bound(int x, int y,int f_color,int b_color) 
{ 
if(getpixel(x,y) != b_color && getpixel(x,y)!= f_color) 
{ 
 	putpixel(x,y,f_color); 
 	bound(x+1,y,f_color,b_color); 
 	bound(x,y+1,f_color,b_color); 
 	bound(x-1,y,f_color,b_color); 
 	bound(x,y-1,f_color,b_color); 
} 
} 

int main() 
{ 
int gm,gd = DETECT; 
initgraph(&gm,&gd,NULL); 
circle(100,200,30); 
bound(100,200,RED,WHITE); 
circle(100,200,50); 
bound(100,160,BLUE,BLACK); 
getch(); 
closegraph(); 
return 0; 
} 

