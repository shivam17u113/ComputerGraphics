/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;

/**
 *
 * @author shivam patil
 */
public class DDA extends JFrame {

 
    public void paint(Graphics g)
    {
     
        int x1,y1,x2,y2,lenght,i;
       
        x1=100;
        y1=100;
        x2=500;
        y2=500;
        
        int dx,dy;
        dx=Math.abs(x2-x1);
        dy=Math.abs(y2-y1);
        
        if(dx>dy)
            lenght=dx;
        else
            lenght= dy;
        i=0;
        
       int  x=x1;
       int y=y1;
       
       int delta_x= (x2-x1)/lenght;
        int delta_y= (y2-y1)/lenght;
       
        while(i<=lenght)
        {
           g.setColor(Color.red);
            g.fillOval(x, y, 2, 2);
            x=x+delta_x;
            y=y+delta_y;
            
            i++;
        }
        
        
    }

    
    
    
    
    
    
    public static void main(String[] args) {
        
        DDA p= new DDA();
        
        p.setSize(1500, 1500);
        p.setVisible(true);
    }
    
}
