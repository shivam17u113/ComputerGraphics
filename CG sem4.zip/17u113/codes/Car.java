/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

import java.awt.Color;
import java.awt.Graphics;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author shivam patil
 */
public class Car extends JFrame 
{

    @Override
    public void paint(Graphics g) 
    {
        try {
            int i=0;
            
            for( i=0;i<500;i++)
            {
              
            g.drawLine(100+i, 100, 200+i, 100);
            
            g.drawLine(200+i, 100, 220+i, 120);
            g.drawLine(220+i, 120, 260+i,140);
            g.drawLine( 260+i,140,260+i,160);
           g.drawLine( 260+i,160,200+i,160);
            
           g.drawRect(100+i, 120, 20 ,20);
           
          g.fillOval( 180+i,150,20,20);
           
            g.drawLine(100+i, 100, 80+i, 120);
          g.drawLine( 80+i, 120,40+i,140);
            g.drawLine( 40+i,140,40+i,160);
            g.drawLine( 40+i,160,80+i,160);
            
                  g.fillOval(80+i, 150,20, 20);
                  
                   g.drawRect(170+i, 120, 20 ,20);
            
            g.drawLine(100+i,160,180+i,160);
            
            g.drawLine(10,170,2000,170);
                
              Thread.sleep(100);
            g.clearRect(0,0, 2000,2000);
                
            }
            
            
            
            
            
            
            
        } catch (InterruptedException ex) {
            Logger.getLogger(Car.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    
    
    
    
    
   
    public static void main(String[] args) 
    {
      Car c= new Car();
      c.setSize(2000, 2000);
      
      c.setVisible(true);
        
       
    }
    
}

/*for( i=0;i<200;i++)
            {
                
                 g.drawLine(200,270,2000, 270);
      
            g.drawRoundRect(200+i,200, 100, 50, 10, 10);
            
            g.drawOval(220+i, 250, 20, 20);
            
            g.drawOval(270+i, 250, 20, 20);
             Thread.sleep(100);
             
            g.clearRect(0, 0, 2000, 2000);
            /* g.setColor(Color.WHITE);
             g.fillRect(0, 0, 2000, 2000);*/
                
                
            