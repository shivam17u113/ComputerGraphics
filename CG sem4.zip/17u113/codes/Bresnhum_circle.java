/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.awt.Graphics;
import javax.swing.JFrame;


public class Bresnhum_circle extends JFrame
{
    

    @Override
    public void paint(Graphics g) 
    {
       int xc,yc,r,d;
    int X,Y;
        xc=500;
      yc=500;
       r=50;
        
       
       d=3-2*r;
       
       Y=r;
       X=0;
       
       draw(xc,yc,X,Y,g);
       
       while(X<=Y)
       {
           X=X+1;
         if(d<0)
         {
             d=d+4*X+6;
             
         }
         else
         {
           Y=Y-1;
           d=d+4*(X-Y)+10;
             
         }
         draw(xc,yc,X,Y,g);
         
           
           
       }
       
        
        
    }
    
   public void draw(int xc,int yc,int X,int Y, Graphics g)
   {
       
       g.fillOval(xc+X, yc+Y, 2, 2);
        g.fillOval(xc+X, yc-Y, 2, 2);
        g.fillOval(xc-X, yc+Y, 2, 2);
          g.fillOval(xc-X, yc-Y, 2, 2);
        
       
         g.fillOval(xc+Y, yc+X, 2, 2);
         g.fillOval(xc+Y, yc-X, 2, 2);
         g.fillOval(xc-Y, yc+X, 2, 2);
         g.fillOval(xc-Y, yc-X, 2, 2);
       
   }
    
    public static void main(String[] args) 
    {
        
        Bresnhum_circle b= new Bresnhum_circle();
        b.setSize(1500, 1500);
        b.setVisible(true);
        
    }
    
    
    
    
    
    
}
