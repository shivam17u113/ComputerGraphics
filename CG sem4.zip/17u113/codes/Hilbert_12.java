/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilbert_12;

import java.applet.Applet;
import java.awt.Graphics;

/**
 *
 * @author shivam patil
 */
public class Hilbert_12 extends Applet
{
simplegraph sg=null;
int dist;

    @Override
    public void init() 
    {
        sg= new simplegraph(getGraphics());
        dist=512;
        
        resize(dist,dist);
        

        
    }

    @Override
    public void paint(Graphics g) 
    {
       int level=4;
       for(int i=level;i>0;i--)
       {
           
         dist/=2;  
       }
        
        sg.gotoXY(dist/2, dist/2);
        
        a(level);
        
    }
    
   public void a(int level)
   {
     if(level>0)
     {
       b(level-1);             sg.drawl(0,dist);
          a(level-1);          sg.drawl(dist,0);
         a(level-1);              sg.drawl(0,-dist);
          c(level-1); 
     }
       
       
   }
   
  public void b(int level)
   {
     if(level>0)
     {
       a(level-1);                  sg.drawl(dist,0);
          b(level-1);              sg.drawl(0,dist);
         b(level-1);                 sg.drawl(-dist,0);
          d(level-1); 
     }
       
       
   }  
   
public void c(int level)
   {
     if(level>0)
     {
       d(level-1);                  sg.drawl(-dist,0);
          c(level-1);               sg.drawl(0,-dist);
         c(level-1);                  sg.drawl(dist,0);
          a(level-1); 
     }
       
       
   }

   public void d(int level)
   {
     if(level>0)
     {
       c(level-1);              sg.drawl(0,-dist);
          d(level-1);            sg.drawl(-dist,0);
         d(level-1);              sg.drawl(0,dist);
          b(level-1); 
     }
       
       
   } 
    
  
}

class simplegraph
{
  Graphics g;
  
int x,y;

public simplegraph(Graphics g)
{
  this.g=g;
    
}

public void gotoXY(int x,int y)
{
    
    
    this.x=x;
    this.y=y;

}

public void drawl(int deltax, int deltay)
{
  g.drawLine(x, y, x+deltax, y+deltay);
  x=x+deltax;
  y=y+deltay;
    
}


}

