package final_submissinon;


import java.awt.*;
import javax.swing.JFrame;
/**
 *
 * @author shivam
 */
public class Assignment2 extends JFrame{ 
    public void paint(Graphics g)
    {
        
        
        g.setColor(Color.BLACK);
        g.fillRect(0, 0,2000, 2000);
       
      g.setColor(Color.orange);
        circle(100,300,400,g);
        g.setColor(Color.orange);
        circle(100,600,400,g);
         g.setColor(Color.blue);
   
  DDA(320,160,194,390,g);
         g.setColor(Color.RED);
DDA(620,160 ,705 , 400,g);
        g.setColor(Color.green);
      DDA(400, 400,500,400,g);
        g.setColor(Color.green);
        
        DDA(400,400,500,400,g);
         DDA(400,405,500,405,g);
        
        
     
    }
    public void circle(int r,int x1,int y1,Graphics g)
    {
    int d=3-2*r;
    int x=0;
    int y=r;
    
    do
    {
      
        g.fillOval(x1+x,y1+y,2,2);
  
        g.fillOval(x1-x,y1+y,2,2);

        g.fillOval(x1+x,y1-y,2,2); 

        g.fillOval(x1-x,y1-y,2,2);

        g.fillOval(x1-y,y1+x,2,2);

        g.fillOval(x1+y,y1-x,2,2);

        g.fillOval(x1-y,y1-x,2,2);
 
        g.fillOval(x1+y,y1+x,2,2);
        
        
        if(d<0)
        {
            d=d+4*x+6;
        }
        else
        {
            d=d+4*(x-y)+10;
            y=y-1;
        }
        x=x+1;
    }
    while(x<y);
       }
   
    public void DDA(int x1,int y1,int x2,int y2,Graphics g)
    {
        g.setColor(Color.red);
  int s1,s2,exchange,x,y,i;
        float dx,dy,e,temp;
        dx=Math.abs(x2-x1);
       dy=Math.abs(y2-y1);
        s1=sign(x2-x1);
        s2=sign(y2-y1);
        x=x1;
        y=y1;
        
        if(dy>dx)
        {
            temp=dx;
            dx=dy;
            dy=temp;
            exchange=1;
           
        }
        else
            exchange =0;
        
          i=1;
            e=2*dy-dx;
          g.fillOval(x, y,5,5);
            while(i<=dx)
            {
                
           
                if(e>=0)
                {
                    x=x+s1;
                    y=y+s2;
                    e=e+2*(dy-dx);
                }
                  else
                  {
                          if(exchange==1)
                              y=y+s2;
                          else
                              x=x+s1;
                          
                          
                     e=e+2*dy;
                     
                      
                }
               
                g.fillOval(x, y, 2, 2);
               i=i+1;
                    
    }
           
            
    }
    public int sign(float arg)
  {
    if(arg<0)
    return -1;
    else if(arg==0)
      return 0;
    else
        return 1;
      
      
  }
    public static void main(String[] args) {
    
        
      
        Assignment2 t=new Assignment2();
        t.setTitle("MYPROJECT");
        t.setSize(1500,1500);
        t.setVisible(true);
    
    
}
}
