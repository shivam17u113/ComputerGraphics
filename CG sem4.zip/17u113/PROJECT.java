/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import static java.lang.Math.abs;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;


public class sub_project extends JFrame  {

    public  static int c_x, c_y;

    public void paint(Graphics g)
    {
        try {
            g.setColor(Color.red);
            DDA(100,100,100,500,g);
            DDA(100,100,200,100,g);
            DDA(200,100,200,500,g);
            //DDA(200,500,100,500,g);
            DDA(100,500,200,500,g);


            // X min, x max, y min , y max
            scanline(105,200,103,500,g);
            g.drawString("SENDER", 120, 600);

            g.drawString("SERIAL TRANSMISSION", 350,80);

            Image image = Toolkit.getDefaultToolkit().getImage("sender.png");

            g.drawImage(image, c_x, c_y, rootPane);

            g.drawString("RECEIVER", 620, 600);

            //x1,x2,y1,y2
            // xmin, xmax, ymin,ymax
            trans(100,200,100,500,200,0,g);
        } catch (InterruptedException ex) {
            Logger.getLogger(sub_project.class.getName()).log(Level.SEVERE, null, ex);
        }

        // FOR THE LINE JOINING THE SENDER AND RECEIVER
        g.setColor(Color.red);
        DDA(200,300,600,300,g);

        int r=10;
        // FOR DATA
        for(int j=0;j<5;j++)
        {



            c_x=220;
            c_y=280;


            g.setColor(Color.blue);
            circle(r,c_x,c_y,g);

            for(int i=0;i<9;i++)
            {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException ex) {
                    Logger.getLogger(sub_project.class.getName()).log(Level.SEVERE, null, ex);
                }
                trans_circle(r,g);
            }


            c_x=220;
            c_y=280;
            g.setColor(Color.white);
            circle(r,c_x,c_y,g);

            for(int i=0;i<9;i++)
            {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException ex) {
                    Logger.getLogger(sub_project.class.getName()).log(Level.SEVERE, null, ex);
                }
                trans_circle(r,g);
            }





        }



        /*c_x=220;
        c_y=280;
     g.setColor(Color.blue);
           circle(r ,c_x,c_y,g);

        for(int i=0;i<9;i++)
        {
            try {
                Thread.sleep(80);
            } catch (InterruptedException ex) {
                Logger.getLogger(sub_project.class.getName()).log(Level.SEVERE, null, ex);
            }
            trans_circle(r,g);
        }*/











        c_x=220;
        c_y=280;
        g.setColor(Color.white);
        circle(r,c_x,c_y,g);

        for(int i=0;i<9;i++)
        {
            try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
                Logger.getLogger(sub_project.class.getName()).log(Level.SEVERE, null, ex);
            }
            trans_circle(r,g);
        }


        g.clearRect(0, 0, 1500, 1500);
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, 1500, 1500);
        g.setColor(Color.WHITE);

        try {
            Thread.sleep(100);
        } catch (InterruptedException ex) {
            Logger.getLogger(sub_project.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            parallel(g);
        } catch (InterruptedException ex) {
            Logger.getLogger(sub_project.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void parallel(Graphics g) throws InterruptedException
    {
        g.setColor(Color.black);
        g.drawString("PARALLEL TRANSMISSION", 350,80);
        g.setColor(Color.red);
        DDA(100,100,100,500,g);
        DDA(100,100,200,100,g);
        DDA(200,100,200,500,g);
        //DDA(200,500,100,500,g);
        DDA(100,500,200,500,g);



        // X min, x max, y min , y max
        scanline(105,200,103,500,g);
        g.drawString("SENDER", 120, 600);




        //x1,x2,y1,y2
        // xmin, xmax, ymin,ymax
        trans(100,200,100,500,200,0,g);

        // FOR THE LINE JOINING THE SENDER AND RECEIVER

        g.drawString("RECEIVER", 620, 600);

        g.setColor(Color.red);
        DDA(200,300,600,300,g);



        DDA(200,200,600,200,g);
        DDA(200,400,600,400,g);
        //DDA()

        // for three packets



        //y1= y= 280;


        int tx;

        for(int j=0; j<5;j++)
        {
            int x_c1=220,y_c1=180;
            int x_c2=220,y_c2=280;
            int x_c3=220,y_c3=380;
            int r=10;

            g.setColor(Color.blue);
            circle(r,x_c1,y_c1,g);
            circle(r,x_c2,y_c2,g);
            circle(r,x_c3,y_c3,g);

            int x,y,x1,y1;
            x1=x=220;


            for(int i=0;i<9;i++)
            {


                Thread.sleep(100);
                g.setColor(Color.blue);
                circle(r,x_c1+40,y_c2,g);
                g.setColor(Color.white);
                circle(r,x_c1,y_c2,g);



                g.setColor(Color.blue);
                circle(r,x_c1+40,y_c1,g);
                g.setColor(Color.white);
                circle(r,x_c1,y_c1,g);



                g.setColor(Color.blue);
                circle(r,x_c1+40,y_c3,g);
                g.setColor(Color.white);
                circle(r,x_c1,y_c3,g);





                x_c1=x_c1+40;









            }
            Thread.sleep(110);
            circle(r,x_c1,y_c1,g);
            circle(r,x_c1,y_c2,g);
            circle(r,x_c1,y_c3,g);

        }
    }

    public void DDA(int x1,int y1,int x2,int y2,Graphics g)
    {
        int t,dx,dy;
        if((x2-x1)>(y2-y1))
            t=x2-x1;
        else
            t=y2-y1;

        dx=(x2-x1)/t;
        dy=(y2-y1)/t;
        int xi=x1;
        int yi=y1;
        int i=1;
        int x,y;
        while(i<=t)
        {
            g.fillOval(xi, yi,5,5);
            xi=xi+dx;
            yi=yi+dy;
            i++;
        }
    }


    public void scanline( int x1,int x2,int y1,int y2,Graphics g)
    {

        int ytemp,ymax=y2;
        int ymin=y1;
        ytemp=ymax;
        while(ytemp>ymin)
        {



            g.setColor(Color.black);
            bresanan (x1-1, ytemp, x2-1, ytemp,g);
            ytemp--;
            try
            {
                Thread.sleep(3);
            }
            catch(InterruptedException ex)
            {
                Thread.currentThread().interrupt();
            }

        }


    }

    public void trans(int x1,int x2, int y1, int y2,int tx, int ty,Graphics g) throws InterruptedException
    {




        tx=500;
        x1=x1+tx;
        x2=x2+tx;

        g.setColor(Color.red);
        Thread.sleep(50);
        DDA(x1, y1, x1, y2 ,g);
        Thread.sleep(50);
        DDA(x1, y1, x2, y1,g);
        Thread.sleep(50);
        DDA(x2, y1, x2, y2,g);
        Thread.sleep(50);
        DDA(x1, y2, x2,y2,g);
        Thread.sleep(50);



        g.setColor(Color.black);
        scanline(605,700,103,500,g);







    }
    // scanv line with out sleep
    public void scanline2( int x1,int x2,int y1,int y2,Graphics g)
    {

        int ytemp,ymax=y2;
        int ymin=y1;
        ytemp=ymax;
        while(ytemp>=ymin)
        {



            g.setColor(Color.black);
            bresanan (x1, ytemp, x2, ytemp,g);
            ytemp--;


        }


    }

    public void trans_circle( int r,Graphics g)
    {

        int tx=40;
        int ty= 40;
        c_x=c_x+tx;
        //c_y=c_y+ty;
        circle(r,c_x,c_y,g);


    }



    public void trans_circle1(int x_c,int y_c, int r,Graphics g)
    {

        int tx=40;
        int ty= 40;
        x_c=x_c+tx;
        //c_y=c_y+ty;
        circle(r,x_c,y_c,g);


    }


    // bresanhm ALGORITHM
    public void bresanan(int x1,int y1,int x2,int y2,Graphics g)
    {
        int s1,s2,exchange,x,y,i;
        float dx,dy,e,temp;
        dx=abs(x2-x1);
        dy=abs(y2-y1);
        s1=sign(x2-x1);
        s2=sign(y2-y1);
        x=x1;
        y=y1;
        g.setColor(Color.black);
        if(dy>dx)
        {
            temp=dx;
            dx=dy;
            dy=temp;
            exchange=1;

        }
        else
            exchange =0;

        i=1;
        e=2*dy-dx;
        g.fillOval(x, y,1,1);
        while(i<=dx)
        {


            if(e>=0)
            {
                x=x+s1;
                y=y+s2;
                e=e+2*(dy-dx);
            }
            else
            {
                if(exchange==1)
                    y=y+s2;
                else
                    x=x+s1;


                e=e+2*dy;


            }

            g.fillOval(x, y, 1, 1);
            i=i+1;

        }

    }
    public int sign(float arg)
    {
        if(arg<0)
            return -1;
        else if(arg==0)
            return 0;
        else
            return 1;


    }
    // CIRCLE DRAWING ALGORITHM
    public void circle(int r,int x1,int y1,Graphics g)
    {
        int d=3-2*r;
        int x=0;
        int y=r;

        do
        {
            //g.setColor(Color.BLUE);
            g.fillOval(x1+x,y1+y,2,2);
            //g.setColor(Color.RED);
            g.fillOval(x1-x,y1+y,2,2);
            //g.setColor(Color.BLACK);
            g.fillOval(x1+x,y1-y,2,2);
            //g.setColor(Color.YELLOW);
            g.fillOval(x1-x,y1-y,2,2);
            //g.setColor(Color.BLUE);
            g.fillOval(x1-y,y1+x,2,2);
            //g.setColor(Color.RED);
            g.fillOval(x1+y,y1-x,2,2);
            //g.setColor(Color.BLACK);
            g.fillOval(x1-y,y1-x,2,2);
            // g.setColor(Color.YELLOW);
            g.fillOval(x1+y,y1+x,2,2);


            if(d<0)
            {
                d=d+4*x+6;
            }
            else
            {
                d=d+4*(x-y)+10;
                y=y-1;
            }
            x=x+1;
        }
        while(x<y);
    }




    public static void main(String[] args)
    {

        sub_project p= new sub_project();


        p.setSize(1500, 1500);
        p.setVisible(true);

    }


}







