package final_submissinon;


import java.awt.*;
import static java.lang.Math.abs;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

public class Assignment1 extends JFrame {
    
    public void paint(Graphics g)
    {
      g.setColor(Color.BLACK);
        g.fillRect(0, 0,2000, 2000);
        
          g.setColor(Color.blue);
        DDA(700,100,500,300,g);
        DDA(300,100,100,300,g);
         DDA(700,500,500,700,g);
         DDA(300,500,100,700,g);
         DDA(100,300,100,700,g);
            DDA(500,300,500,700,g);
            
           g.setColor(Color.red);
         bresanan(300,100,700,100,g);
         bresanan(300,500,700,500,g); 
          bresanan(100,300,500,300,g);
           bresanan(100,700,500,700,g);
          
           
            bresanan(700,100,700,500,g);
          bresanan(300,100,300,500,g);
          
         
           
           
        
    }
    public void DDA(int x1,int y1,int x2,int y2,Graphics g)
    {
int t,dx,dy;
       if((x2-x1)>(y2-y1))
       t=x2-x1;
       else
       t=y2-y1;
       
       dx=(x2-x1)/t;
       dy=(y2-y1)/t;
       int xi=x1;
       int yi=y1;
       int i=1;
       int x,y;
       while(i<=t)
       {
           g.fillOval(xi, yi,5,5);
           xi=xi+dx;
           yi=yi+dy;
           i++;
       }
       }
    
    public void bresanan(int x1,int y1,int x2,int y2,Graphics g)
    {
        int s1,s2,exchange,x,y,i;
        float dx,dy,e,temp;
        dx=abs(x2-x1);
        dy=abs(y2-y1);
        s1=sign(x2-x1);
        s2=sign(y2-y1);
        x=x1;
        y=y1;
        
        if(dy>dx)
        {
            temp=dx;
            dx=dy;
            dy=temp;
            exchange=1;
           
        }
        else
            exchange =0;
        
          i=1;
            e=2*dy-dx;
          g.fillOval(x, y,5,5);
            while(i<=dx)
            {
                
           
                if(e>=0)
                {
                    x=x+s1;
                    y=y+s2;
                    e=e+2*(dy-dx);
                }
                  else
                  {
                          if(exchange==1)
                              y=y+s2;
                          else
                              x=x+s1;
                          
                          
                     e=e+2*dy;
                     
                      
                }
                g.setColor(Color.YELLOW);
                g.fillOval(x, y, 2, 2);
               i=i+1;
                    
    }           
       
    }
  public int sign(float arg)
  {
    if(arg<0)
    return -1;
    else if(arg==0)
      return 0;
    else
        return 1;
      
      
  }
                
                
            
            
            public static void main(String[] args) {
        // TODO code application logic hereMyProject
        Assignment1 t=new Assignment1();
        t.setTitle("MYPROJECT 8888");
        t.setSize(2000,2000);
        t.setVisible(true);
    
    
}
       
            
        
        
        
        
        
        
        
        
        
        
        
        
    }
                
                
                
                
            
        
    
    
