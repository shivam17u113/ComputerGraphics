/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanline1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.*;
import javax.swing.JFrame;
public class Scanline extends JFrame
{
public void paint(Graphics g) 
{
    g.drawLine(500, 100, 100, 500);
     g.drawLine(100, 500, 700, 500);
      g.drawLine(700, 500, 500, 100);
      
      int a,b,c;
      a=-1;b=0;c=2;
      int ytemp,ymax=500,ymin=100;
      ytemp=ymax;
      while(ytemp>=ymin)
      {
          int x1,x2;
          
          x1=(ytemp-600)/a;
          x2=(ytemp+900)/c;
          g.setColor(Color.cyan);
          g.drawLine(x1, ytemp, x2, ytemp);
                  ytemp--;
                  try
                  {
                      Thread.sleep(10);
                  }
                  catch(InterruptedException ex)
                  {
                      Thread.currentThread().interrupt();
                  }
                  
      }
} 
    public static void main(String[] args)
    {
     Scanline s= new Scanline();
     s.setTitle("SCANLINE");
     s.setSize(1000, 1000);
     s.setVisible(true);
    }
    
}

