/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package final_submissinon;

import java.awt.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Assignment5 extends JFrame
{
    
     static int size = 3;
     static double theta;
    static int [][] vert = new int[size][3];
  
    static double [][] t_mat = new double[3][3];
    static double [][] s_mat = new double[3][3];
    static double [][] r_mat = new double[3][3];
    
    
    static int [][] c = new int[size][3];
    

    
    
     public static  void mat_mul(int a[][], double b[][])
    {
        for(int i=0;i<size;i++)
        {    
            for(int j=0;j<3;j++)
            {    
                c[i][j]=0;      
                for(int k=0;k<size;k++)      
                {      
                    c[i][j]= (int)(a[i][k]*b[k][j]+c[i][j]);      
                }
                //System.out.print(" "+c[i][j]);
            }
            
        }
    }
    
    
    
     public void paint(Graphics g)
    {
         g.setColor(Color.BLACK);
        g.fillRect(0, 0,2000, 2000);
        
        
      vert[0][0] = 200;
        vert[0][1] = 200;
        vert[0][2] = 1;
        vert[1][0] = 100;
        vert[1][1] = 500;
        vert[1][2] = 1;
        vert[2][0] = 300;
        vert[2][1] = 500;
        vert[2][2] = 1;
        
        t_mat[0][0] = 1;
        t_mat[0][1] = 0;
        t_mat[0][2] = 0;
        t_mat[1][0] = 0;
        t_mat[1][1] = 1;
        t_mat[1][2] = 0;
        t_mat[2][0] = 400;
        t_mat[2][1] = 0;
        t_mat[2][2] = 1;
        
        s_mat[0][0] = 3;
        s_mat[0][1] = 0;
        s_mat[0][2] = 0;
        s_mat[1][0] = 0;
        s_mat[1][1] = 1;
        s_mat[1][2] = 0;
        s_mat[2][0] = 0;
        s_mat[2][1] = 0;
        s_mat[2][2] = 1;
        
        
        int angle=-5;
        theta= ((Math.PI*angle)/180);
        
        System.err.println("the radian angle is"+theta);
        
        r_mat[0][0]=Math.cos(theta);
         r_mat[0][1]=Math.sin(theta);
          r_mat[0][2]=0;
       r_mat[1][0]= -Math.sin(theta);
         r_mat[1][1]=Math.cos(theta);
           r_mat[1][2]=0;  
           r_mat[2][0]=0;
             r_mat[2][1]=0;
             r_mat[2][2]=1;
             
            
             
             System.err.println("the original matrix is");
        for( int p=0;p<3;p++)
        {
             System.err.print("\n");
          for(int k=0;k<3;k++)
          {
               System.err.print("\t");
              System.err.print(vert[p][k]);
             
              
          }
         
            
        }
             
              System.err.println("the rotation matrix is ");
        for( int p=0;p<3;p++)
        {
             System.err.print("\n");
          for(int k=0;k<3;k++)
          {
               System.err.print("\t");
              System.err.print(r_mat[p][k]);
             
              
          }
         
            
        }
             
             
             
        System.err.println();
             // translation
         g.setColor(Color.BLUE);     
        dr_vert(g);
        mat_mul(vert,t_mat); 
       System.err.println("the traslation new matrix is ");
        
         dr(g);
  
     
        try {
             Thread.sleep(1000);
         } catch (InterruptedException ex) {
             Logger.getLogger(Assignment5.class.getName()).log(Level.SEVERE, null, ex);
         }
        
     g.clearRect(0, 0, 1500,1500);
     g.setColor(Color.white);
     
     g.fillRect(0, 0, 1500, 1500);
     g.setColor(Color.BLACK);
        g.fillRect(0, 0,2000, 2000);
           
         
   // scaling
         System.err.println();
      g.setColor(Color.BLUE);
        dr_vert(g);
        mat_mul(vert,s_mat);
        System.err.println("scaling new matrx is");
        dr(g);
        
        
      
        
     
       try {
             Thread.sleep(1000);
         } catch (InterruptedException ex) {
             Logger.getLogger(Assignment5.class.getName()).log(Level.SEVERE, null, ex);
         }
        
      g.clearRect(0, 0, 1500,1500);
     g.setColor(Color.white);
     g.fillRect(0, 0, 1500, 1500); 
     g.setColor(Color.BLACK);
        g.fillRect(0, 0,2000, 2000);
        
        
     // rotation
      g.setColor(Color.BLUE);
        dr_vert(g);
        mat_mul(vert,r_mat);
          System.err.println("the rotation new matrix is ");  
        dr(g);
     
     
}
     
      public static void dr(Graphics g)
    {
        g.setColor(Color.MAGENTA);
        
        int i;
        
         
        System.err.println();
        for( int p=0;p<3;p++)
        {
             System.err.print("\n");
          for(int k=0;k<3;k++)
          {
               System.err.print("\t");
              System.err.print(c[p][k]);
             
              
          }
         
            
        }
        
        
  
        for(i=0;i<size;i++)
        {
            g.drawLine(c[i%size][0], c[i%size][1], c[(i+1)%size][0], c[(i+1)%size][1]);
        }
    }
     
      
     /* public static void dr_r(Graphics g)
    {
        g.setColor(Color.MAGENTA);
        
        int i;
  
        for(i=0;i<size;i++)
        {
            g.drawLine(c_r[i%size][0], c_r[i%size][1], c_r[(i+1)%size][0], c_r[(i+1)%size][1]);
        }
    }*/
      
      
      
       public static void dr_vert(Graphics g)
    {
        g.setColor(Color.blue);
        
        int i;
  
        for(i=0;i<size;i++)
        {
            g.drawLine( vert[i%size][0], vert[i%size][1], vert[(i+1)%size][0], vert[(i+1)%size][1]);
        }
    }
      
      
      
      public static void main(String[] args) 
          {
            
              Assignment5 a= new Assignment5();
           
              a.setSize(1500,1500);
                 a.setVisible(true);
              
          }
      

}